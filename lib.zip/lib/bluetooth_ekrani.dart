import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';

class BluetoothEkrani extends StatefulWidget {
  @override
  _BluetoothEkraniState createState() => _BluetoothEkraniState();
}

class _BluetoothEkraniState extends State<BluetoothEkrani> {
  FlutterBlue flutterBlue = FlutterBlue.instance;
  List<ScanResult> scanResults = [];

  @override
  void initState() {
    super.initState();
    _startScan();
  }

  void _startScan() {
    flutterBlue.startScan(timeout: Duration(seconds: 4));

    flutterBlue.scanResults.listen((results) {
      setState(() {
        scanResults = results;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Bluetooth Tarama')),
      body: scanResults.isEmpty
          ? Center(child: Text('Cihaz bulunamadı veya tarama yapılmadı.'))
          : ListView.builder(
              itemCount: scanResults.length,
              itemBuilder: (context, index) {
                final cihaz = scanResults[index].device;
                return ListTile(
                  title: Text(cihaz.name.isEmpty ? 'Bilinmeyen Cihaz' : cihaz.name),
                  subtitle: Text(cihaz.id.id),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.search),
        onPressed: _startScan,
        tooltip: 'Tarama başlat',
      ),
    );
  }
}
