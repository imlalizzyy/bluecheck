import 'package:flutter/material.dart';
import 'ogrenci_ekrani.dart'; // geçici olarak öğrenci ekranına gideceğiz

class GirisYapFormu extends StatefulWidget {
  @override
  _GirisYapFormuState createState() => _GirisYapFormuState();
}

class _GirisYapFormuState extends State<GirisYapFormu> {
  final ogrenciNoController = TextEditingController();
  final sifreController = TextEditingController();

  void girisYap() {
    String no = ogrenciNoController.text;
    String sifre = sifreController.text;

    // Şu an sabit örnek veri, veritabanı eklendiğinde burada kontrol olacak
    if (no == "12345" && sifre == "1234") {
      Navigator.push(context, MaterialPageRoute(builder: (context) => OgrenciEkrani()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Öğrenci No veya Şifre yanlış!")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Giriş Yap')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: ogrenciNoController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Öğrenci Numarası'),
            ),
            TextField(
              controller: sifreController,
              obscureText: true,
              decoration: InputDecoration(labelText: 'Şifre'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('Giriş Yap'),
              onPressed: girisYap,
            ),
          ],
        ),
      ),
    );
  }
}
