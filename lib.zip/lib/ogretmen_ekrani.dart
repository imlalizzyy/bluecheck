import 'package:flutter/material.dart';

class OgretmenEkrani extends StatefulWidget {

  
  const OgretmenEkrani({Key? key}) : super(key: key);

  @override
  _OgretmenEkraniState createState() => _OgretmenEkraniState();
}

class _OgretmenEkraniState extends State<OgretmenEkrani> {
  List<String> yoklamayaKatilanlar = [];

  void dersiBaslat() {
    // Geçici olarak örnek öğrenciler ekleniyor (Bluetooth verisi burada toplanacak)
    setState(() {
      yoklamayaKatilanlar = [
        'Fatma - 00:1A:7D:DA:71:13',
        'Ali - 00:1A:7D:DA:71:99',
        'Zeynep - 00:1A:7D:DA:71:22',
      ];
    });
  }

  void yoklamayiKaydet() {
    // Geçici: Konsola yazdırılıyor, ileride veritabanına kaydedilecek
    print("Yoklama kaydedildi: $yoklamayaKatilanlar");

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("📋 Yoklama başarıyla kaydedildi!"),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Öğretmen Ekranı'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton.icon(
              onPressed: dersiBaslat,
              icon: const Icon(Icons.play_arrow),
              label: const Text("Dersi Başlat (Bluetooth Taraması)"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: yoklamayaKatilanlar.isEmpty
                  ? const Center(child: Text("Henüz yoklama alınmadı."))
                  : ListView.builder(
                      itemCount: yoklamayaKatilanlar.length,
                      itemBuilder: (context, index) {
                        return Card(
                          child: ListTile(
                            leading: const Icon(Icons.person),
                            title: Text(yoklamayaKatilanlar[index]),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: yoklamayiKaydet,
              icon: const Icon(Icons.save),
              label: const Text("Yoklamayı Kaydet"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey),
            ),
          ],
        ),
      ),
    );
  }
}
