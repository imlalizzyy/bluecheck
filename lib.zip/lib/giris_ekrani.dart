import 'package:flutter/material.dart';
import 'kaydol_formu.dart';
import 'ogretmen_ekrani.dart';
import 'ogrenci_ekrani.dart';

class GirisEkrani extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('BlueCheck Giriş')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Hoş geldiniz!', style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),

            // 🧑‍🏫 Öğretmen Butonu
            ElevatedButton(
              child: Text('Giriş Yap (Öğretmen)'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OgretmenEkrani()),
                );
              },
            ),

            SizedBox(height: 10),

            // 👨‍🎓 Öğrenci Butonu
            ElevatedButton(
              child: Text('Giriş Yap (Öğrenci)'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OgrenciEkrani()),
                );
              },
            ),

            SizedBox(height: 30),

            // Kaydol Butonu
            ElevatedButton(
              child: Text('Kaydol'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => KaydolEkrani()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
