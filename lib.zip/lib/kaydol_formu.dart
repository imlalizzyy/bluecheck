import 'package:flutter/material.dart';

class KaydolEkrani extends StatefulWidget {
  const KaydolEkrani({Key? key}) : super(key: key);

  @override
  _KaydolEkraniState createState() => _KaydolEkraniState();
}

enum Cinsiyet { kadin, erkek, belirtilmedi }

class _KaydolEkraniState extends State<KaydolEkrani> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController ogrenciNoController = TextEditingController();
  final TextEditingController adController = TextEditingController();
  final TextEditingController soyadController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController sifreController = TextEditingController();

  DateTime? dogumTarihi;
  Cinsiyet? secilenCinsiyet = Cinsiyet.belirtilmedi;
  bool kvkkOnaylandi = false;

  Future<void> _dogumTarihiSec(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: dogumTarihi ?? DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != dogumTarihi) {
      setState(() {
        dogumTarihi = picked;
      });
    }
  }

  void kaydol() {
    if (!_formKey.currentState!.validate()) return;

    if (dogumTarihi == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen doğum tarihinizi seçin')),
      );
      return;
    }

    if (secilenCinsiyet == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen cinsiyet seçin')),
      );
      return;
    }

    if (!kvkkOnaylandi) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('KVKK onayı gereklidir')),
      );
      return;
    }

    // Kayıt işlemi burada yapılacak
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Kayıt başarılı!')),
    );
  }

  @override
  void dispose() {
    ogrenciNoController.dispose();
    adController.dispose();
    soyadController.dispose();
    emailController.dispose();
    sifreController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kayıt Ol'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Öğrenci No
              TextFormField(
                controller: ogrenciNoController,
                decoration: const InputDecoration(
                  labelText: 'Öğrenci No',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Öğrenci numarası boş olamaz';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Ad
              TextFormField(
                controller: adController,
                decoration: const InputDecoration(
                  labelText: 'Ad',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Adınızı girin';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Soyad
              TextFormField(
                controller: soyadController,
                decoration: const InputDecoration(
                  labelText: 'Soyad',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Soyadınızı girin';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Doğum Tarihi
              InkWell(
                onTap: () => _dogumTarihiSec(context),
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Doğum Tarihi',
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  child: Text(
                    dogumTarihi == null
                        ? 'Tarih seçiniz'
                        : '${dogumTarihi!.day.toString().padLeft(2, '0')}/'
                            '${dogumTarihi!.month.toString().padLeft(2, '0')}/'
                            '${dogumTarihi!.year}',
                    style: TextStyle(
                      color: dogumTarihi == null ? Colors.grey.shade600 : Colors.black,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Cinsiyet (Radio Button)
              const Text('Cinsiyet', style: TextStyle(fontWeight: FontWeight.bold)),
              ListTile(
                title: const Text('Kadın'),
                leading: Radio<Cinsiyet>(
                  value: Cinsiyet.kadin,
                  groupValue: secilenCinsiyet,
                  onChanged: (Cinsiyet? value) {
                    setState(() {
                      secilenCinsiyet = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text('Erkek'),
                leading: Radio<Cinsiyet>(
                  value: Cinsiyet.erkek,
                  groupValue: secilenCinsiyet,
                  onChanged: (Cinsiyet? value) {
                    setState(() {
                      secilenCinsiyet = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text('Belirtilmedi'),
                leading: Radio<Cinsiyet>(
                  value: Cinsiyet.belirtilmedi,
                  groupValue: secilenCinsiyet,
                  onChanged: (Cinsiyet? value) {
                    setState(() {
                      secilenCinsiyet = value;
                    });
                  },
                ),
              ),
              const SizedBox(height: 16),

              // E-posta
              TextFormField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'E-posta',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'E-posta girin';
                  }
                  if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                    return 'Geçerli e-posta girin';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Şifre
              TextFormField(
                controller: sifreController,
                decoration: const InputDecoration(
                  labelText: 'Şifre',
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Şifre girin';
                  }
                  if (value.length < 6) {
                    return 'Şifre en az 6 karakter olmalı';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              CheckboxListTile(
                title: const Text(
                  'Kişisel verilerimin KVKK kapsamında işlenmesini kabul ediyorum.',
                  style: TextStyle(fontSize: 14),
                ),
                value: kvkkOnaylandi,
                onChanged: (bool? value) {
                  setState(() {
                    kvkkOnaylandi = value ?? false;
                  });
                },
                controlAffinity: ListTileControlAffinity.leading,
              ),
              const SizedBox(height: 8),
              const Text(
                'Kişisel verileriniz, 6698 sayılı Kişisel Verilerin Korunması Kanunu kapsamında korunmakta ve sadece uygulamanın işleyişi için kullanılacaktır.',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 24),

              ElevatedButton(
                onPressed: kaydol,
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14),
                  child: Text('Kayıt Ol', style: TextStyle(fontSize: 18)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
