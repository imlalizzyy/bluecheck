package com.example.bluecheck

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
